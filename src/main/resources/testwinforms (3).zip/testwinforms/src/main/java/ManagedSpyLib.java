import net.sf.jni4net.Bridge;

import java.io.File;
import java.io.IOException;

public class ManagedSpyLib {

    private static Boolean isLoaded = false;

    public static void init(){
        if(isLoaded == false) {
            try {
                Bridge.init(new File(System.getProperty("user.dir")+"\\jni4net.n.w64.v40-0.8.8.0.dll"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            Bridge.LoadAndRegisterAssemblyFrom(new File(System.getProperty("user.dir")+"\\ManagedSpy4Java.dll"));
            isLoaded = true;
        }
    }
}
