/* Copyright (C) 2009 by Pavel Savara
This file is part of of jni4net - bridge between Java and .NET
http://jni4net.sourceforge.net/

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import microsoft.managedspy.ControlProxy;
import net.sf.jni4net.Bridge;
import net.sf.jni4net.BridgeSetup;
import system.Environment;
import system.collections.IEnumerator;
import system.reflection.BindingFlags;

import java.io.File;
import java.io.IOException;

/**
 * @author Pavel Savara (original)
 */
public class Program {
	public static void main(String[] args) throws IOException {
		ManagedSpyLib.init();
       // System.setProperty("java.library.path","C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources");
		//Bridge.init(new File("C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources\\jni4net.n.w64.v40-0.8.9.0.dll"));
		//Bridge.LoadAndRegisterAssemblyFrom(new File("C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources\\ManagedSpy4Java.dll"));
		//NativeWindowHandle	69698
		ControlProxy cp = ControlProxy.FromHandle(69698);
		system.Object b = cp.GetValue("Text");
		system.String cd = (system.String) cp.GetValue("Text");
		System.out.println(cp.GetClassName());
		cp.SetValue("Text", new system.String("OK"));
	}

	public static void printAllPropertiesAndValues(ControlProxy cp){
		system.componentmodel.PropertyDescriptorCollection propertyDescriptorCollection = cp.GetProperties();
		IEnumerator enumerator = propertyDescriptorCollection.getKeys().GetEnumerator();
		for(int i = 0; i < propertyDescriptorCollection.getCount(); i++){
			enumerator.MoveNext();
			String propertyName = enumerator.getCurrent().toString();
			System.out.println(propertyName + " = " + cp.GetValue(propertyName));
		}
	}
}
