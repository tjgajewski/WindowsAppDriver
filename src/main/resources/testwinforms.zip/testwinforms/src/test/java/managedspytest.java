import net.sf.jni4net.Bridge;
import system.Console;
import system.Object;
import system.Type;
import system.reflection.Assembly;
import system.reflection.ConstructorInfo;
import system.reflection.MethodInfo;
import system.reflection.ParameterInfo;

import java.io.File;
import java.io.IOException;

public class managedspytest {

    public static void main(String[] args) throws IOException {






        System.setProperty("java.library.path","C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources");
        Bridge.setVerbose(true);
        Bridge.init(new File("C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources\\jni4net.n.w64.v40-0.8.8.0.dll"));
        Bridge.LoadAndRegisterAssemblyFrom(new File("C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources\\ManagedSpyLib.dll"));
        Assembly objAssembly = Assembly.LoadFrom("C:\\Users\\HB427JN\\Documents\\testwinforms\\src\\main\\resources\\ManagedSpyLib.dll");
        Bridge.RegisterAssembly(objAssembly);
        Type[] types = objAssembly.GetTypes();
        for (Type type : types)
        {
            MethodInfo[] methodInfos = type.GetMethods();
            for (MethodInfo methodInfo : methodInfos)
            {
                ParameterInfo[] parameterInfos = methodInfo.GetParameters();
                StringBuilder br = new StringBuilder();
                for(ParameterInfo p : parameterInfos){
                    br.append(p.getName()+" ");
                }
                Console.WriteLine(methodInfo.getName() + " from " + type.getFullName() + " has paramater " + br.toString());
            }

        }
        Type controlProxy = objAssembly.GetType("Microsoft.ManagedSpy.ControlProxy");
        //system.Object intstance = controlProxy.GetConstructor(null).Invoke(null);




        system.reflection.MethodInfo fromHandle = controlProxy.GetMethod("FromHandle");
        system.reflection.MethodInfo setProperty = controlProxy.GetMethod("SetValue");
        Type c = Type.GetType("System.Convert");
        MethodInfo l = c.GetMethod("ToInt32", new system.Type[] { system.Object.typeof() });
        system.Object int32Obj = l.Invoke(null, new Object[] { new system.String("200346") });
        Type intPtrType = Type.GetType("System.IntPtr");
        ConstructorInfo intPtrConstructor = intPtrType.GetConstructor(new Type[] { Type.GetType("System.Int32") });
        system.Object intPtr = intPtrConstructor.Invoke(new system.Object[] { int32Obj });
        system.Object buttonInstance = fromHandle.Invoke(null, new system.Object[] { intPtr});
        setProperty.Invoke(buttonInstance, new system.Object[] { new system.String("Text"), new system.String("YESSS") });

    }
}
